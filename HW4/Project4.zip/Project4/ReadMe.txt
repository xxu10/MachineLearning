Unzip the 'Project4.rar'

Put 'week6.mat' into Project4(The same position as week1 2 3 4 5. mat)

Click 'pj4.py' and follow the note to use week6.mat as the test datasets